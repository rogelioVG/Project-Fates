﻿using UnityEngine;
using System.Collections;

public class Unit
{
    #region Atributos
   
    #endregion

}

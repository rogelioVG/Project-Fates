﻿using UnityEngine;
using System.Collections;

public class ReferenceInfoScript : MonoBehaviour {


	public int iX;
	public int iY;
	public Tile[,] tileMat;


	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
